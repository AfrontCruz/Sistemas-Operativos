* =====================================================
* this part set in vimrc
* created by Chen Xu
* email: chenxu@mail.ustc.edu.cn
* copyright cx
* Darwin newas.local 17.6.0 Darwin Kernel Version 17.6.0: Tue May  8 15:22:16 PDT 2018; root:xnu-4570.61.1~1/RELEASE_X86_64 x86_64
* Last modify:
* 2018年 6月16日 星期六 14时06分33秒 CST
* =====================================================

a cpp version Base on github:hexinal/mathematica-keygen
